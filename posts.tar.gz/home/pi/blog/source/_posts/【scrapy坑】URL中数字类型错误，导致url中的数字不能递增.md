---
title: URL中数字类型错误，导致url中的数字不能递增
date: 2020-03-20 21:22:10
categories: 
- scrapy
tags: 
- scrapy
urlname: scrapy_type
description: scrapy中，有需要对URL进行组合，比如URL中有关于页数，比如展示内容数量，我这个基础不扎实的家伙，实际碰到Python的数据类型，也会翻车。
---
### 问题情况
scrapy中，有需要对URL进行组合，比如URL中有关于页数，比如展示内容数量，我这个基础不扎实的家伙，实际碰到Python的数据类型，也会翻车。
额，群里一好友在上个星期的时候，问我：【为什么我写的scapy代码，不能翻页了】
然后丢给我压缩包。
然后……

咕咕咕，我鸽了好几天。咕~~~~~

### 实际代码
```
class WorldSpider(scrapy.Spider):
    name = "world"
    allowed_domains = ["j****.com"]
    base = 'http://www.****/xinwen/****'
    set = "1"
    end_url = '.html'
    start_urls = [base + str(set) + end_url]


···中间省略十几行代码。。。。嗯大概···

        #问过他本人，他考虑的是人工组合一下url
        if self.set < 15:
            self.set += 1
            url = self.base + str(self.set) + self.end_url
            
            print self.set
            yield scrapy.Request(url, callback=self.parse)
            
```

### 问题分析
原始代码的部分截取，
代码中的set = "1"，
下面有需求，
需要组合成**http://www.dsdfsdf.cm/｛set｝.html**
数字自增，要**int类型**，
二话不说，直接改成**set = 1**
运行一下代码，
编辑器报了一些错误：
具体是url这块的类型有问题，但是又没有严重影响url
不考虑严谨性，就这样了。