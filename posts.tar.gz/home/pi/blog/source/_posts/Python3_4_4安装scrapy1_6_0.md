---
title: 32位xp系统 Python3.4.4安装scrapy1.6.0
date: 2020-03-13 21:29:59

categories: 
- python
tags:
- scrapy
urlname: xp_scrapy
description: Python3 XP系统能安装的最后一个版本为Python3.4.4,以前在XP机子上安装过scrapy，还成功跑了python3的爬虫，不可能现在就安装不起来。这篇文章除了吐槽XP没人权以外，还是想介绍一下XP安装上scrapy（1.6.0）版本，继续跑。
---
## 32XP系统没人权！！！！

Python3 XP系统能安装的最后一个版本为**Python3.4.4**
以前在XP机子上安装过scrapy，还成功跑了python3的爬虫，不可能现在就安装不起来

于是不管怎么样，打开命令行工具，输入**pip install scrapy**
按照以往惯例，会有几次报错：比如C++ 10 C++14之类的ERROR
直接打开https://www.lfd.uci.edu/~gohlke/pythonlibs/
搜索相关**第三方库**的安装包
居然大多数第三方库**没有cp34**！！！

## 32XP系统没人权！！！！
把系统中的python全部删除，下载了Anaconda3-2.3.0-Windows-x86.exe（Python3.4.3）

其实完全可以不用安装Anaconda3，我这里只是为了方便
进到Anaconda组件中，打开【Anaconda Command Prompt】
pip install scrapy==1.6.0，pip 下载源更改 需自行百度

**pyOpenSSL cryptography OpenSSL**报错的多数是这三个
去官方下载源码，**安装源码、降版本、安装**最新版本都试过
然而都没用。

后来发现了这个https://blog.csdn.net/qq_39944630/article/details/80714580，
于是按照里面的这个，去搜索了Twisted 32位
下面百度盘包含：
Twisted-18.7.0-cp34-cp34m-win32.whl
安装这个-Twisted-18.7.0-cp34-none-win32.whl
链接: https://pan.baidu.com/s/1z5jxrzxSVKo4Am_pFX2CNQ 提取码: 2zdj

下载Twisted-18.7.0-cp34-none-win32.whl CD到下载目录→pip install Twisted-18.7.0-cp34-none-win32.whl→安装完毕后，再执行pip install scrapy。

如果不出意外的话，scrapy能安装了，但是执行scrapy项目的时候，还报错win32啥信息，
二话不说执行pip install pywin32
然后该干啥干啥

本文内容借鉴：
[python3.4安装scrapy的各种坑](https://blog.csdn.net/qq_39944630/article/details/80714580)
