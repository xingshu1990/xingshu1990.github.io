---
title: '关键词规划师,用python获取流量关键词'
categories: 
- python

tags:
- 关键词规划师

urlname: pykeyword
description: 百度推广后台中，有一个免费的关键词来源：关键词规划师，学一点Python代码，通过python采集获取高的流量关键词，使网站抢占更多、更好的流量。
---

## 说明
- 此篇文章代码较多，建议PC端浏览
- config 以及 cookie需要自行抓包填写，数据来源为抓包'关键词规划师'
- userid为整数类型，token、eventId、reqid为字符串类型
- 后续为了方便python新人，会放上教学图片

## 需求分析
百度竞价中的关键词规划师，是SEO从业者很好的关键词来源。
那要如何才能获取这里的关键词内容呢？
本代码是基于网络上2.7的版本，修改成3.*也能使用。
（其实根本就只是改了一下print，2333）

本代码没有一步步教你如何解决登陆、获取cookie的问题，直接是采用登陆后的cookie，以及登陆后的from_data数据。注意看下面代码中顶部的注释，不然运行不起来别怪我。

```python
# -*- coding: utf-8 -*-
#本代码改编自网络上Python2.7版本代码。
#Python版本：3.*，需要安装requests，JSON库不知道要不要重新安装
#使用本代码，首先将代码保存为.py文件，并且在相同目录中新建名字为cigeng的txt文件
#在cigeng.txt文件中输入要采集的关键词，一行一个。保存。
#成功采集后的数据，保存在相同目录中resultkeys.txt文件中。
#如果只要关键词，不要其他黑马等数据，那么就修改key_data函数下else中的数据。
import requests
import json
import time

def url_data(key,config,cookie,shibai=3):
    headers={
            'Accept': '*/*',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'zh-CN,zh;q=0.8,en;q=0.6',
            'Connection': 'keep-alive',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Cookie': cookie,#在下面config这个变量值下面的cookie中粘贴进抓包后的cookie，这里不要动。
            'Host': 'fengchao.baidu.com',
            'Origin': 'http://fengchao.baidu.com',
            'Referer': 'http://fengchao.baidu.com/nirvana/main.html?userid=%s' % config['userid'],
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 '
            '(KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36'
    }
    params={
            "logid":401075077,
            "query":key,
            "querySessions":[key],
            "querytype":1,
            "regions":"16",
            "device":0,
            "rgfilter":1,
            "entry":"kr_station",
            "planid":"0",
            "unitid":"0",
            "needAutounit":False,
            "filterAccountWord":True,
            "attrShowReasonTag":[],
            "attrBusinessPointTag":[],
            "attrWordContainTag":[],
            "showWordContain":"",
            "showWordNotContain":"",
            "pageNo":1,
            "pageSize":1000,
            "orderBy":"",
            "order":"",
            "forceReload":True
    }
    from_data={
            'params':json.dumps(params),
            'path':'jupiter/GET/kr/word',
            'userid':config['userid'],
            'token':config['token'],
            'eventId':config['eventId'],
            'reqid':config['reqid']
    }
    qurl="http://fengchao.baidu.com/nirvana/request.ajax?path=jupiter/GET/kr/word&reqid=%s"%config['reqid']
    try:
        whtml=requests.post(qurl,headers=headers,data=from_data)
    except requests.exceptions.RequestException:
        resultitem={}
        erry="请求三次都是错误！"
        if shibai > 0:
            return url_data(key,config,cookie,shibai-1)
    else:
        whtml.encoding="utf-8"
        try:
            resultitem = whtml.json()
        except ValueError:
            resultitem = {}
            erry = "获取不到json数据，可能是被封了吧，谁知道呢？"
        else:
            erry = None
    return resultitem,erry
    
config={
#这部分数据和下面的cookie，直接开浏览器抓包就能看到相应数据。复制黏贴到相应位置
        'userid': '',
        'token':'',
        'eventId':'',
        'reqid':''
}
cookie="  "
def key_data(resultitem):
    kws=['关键词\t日均搜索量\tpc\t移动\t竞争度\n']
    try:
        resultitem=resultitem['data']['group'][0]['resultitem']
    except (KeyError, ValueError, TypeError):
        resultitem=[]
        erry="没有获取到关键词"
    else:
        for items in resultitem:
        #如果你只想要关键词，那么只保留word就可以。
            word=items['word']
            pv=items['pv']#日均搜索量
            pvPc=items['pvPc']
            pvWise=items['pvWise']
            kwc=items['kwc']#竞争度
            kwslist=str(word)+'\t'+str(pv)+'\t'+str(pvPc)+'\t'+str(pvWise)+'\t'+str(kwc)+'\n'
            kws.append(str(kwslist))
            print (word,pv,pvPc,pvWise,kwc)
##          kws.append(str(word))
##          print (word)
        erry=None
    return kws,erry
    
    
sfile = open('resultkeys.txt', 'w')  # 结果保存文件
faileds = open('faileds.txt', 'w')  # 查询失败保存文件
for key in open("cigeng.txt"):  #要查询的关键词存放的载体，一行一个，同当前代码文件相同目录。
    key=key.strip()
    print ("正在拓展:%s"%key)
    resultitem,erry=url_data(key,config,cookie)
    if erry:
        print (key,erry)
        faileds.write('%s\n' % key)
        faileds.flush()
        continue
    keylist,erry=key_data(resultitem)
    if erry:
        print (key,erry)
        faileds.write('%s\n' % word)
        faileds.flush()
        continue
    for kw in keylist:
        sfile.write('%s\n'%kw)
        faileds.flush()
        continue
```

下面的代码由浏览器（360极速浏览器）抓包，[https://curl.trillworks.com/#](https://links.jianshu.com/go?to=https%3A%2F%2Fcurl.trillworks.com%2F%23)（需要挂梯子）网站格式化后的数据，没有做任何更改。方便新人理解。需要导入JSON，用JSON解析代码，不过要注意JSON含的内容太多，小心IDLE卡死。



```Python
import requests

cookies = {'这部分有数据的，我删了，自己抓包后就知道'
}

headers = {
    'Origin': 'http://fengchao.baidu.com',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'zh-CN,zh;q=0.9',
    'User-Agent': 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36',
    'Content-Type': 'application/x-www-form-urlencoded',
    'Accept': '*/*',
    'Referer': 'http://fengchao.baidu.com/nirvana/main.html?userid=6941153',
    'Connection': 'keep-alive',
}

params = (
    ('path', 'jupiter/GET/kr/word'),
    ('reqid', '4b534c46-1ea0-4eca-b581-154181423578'),
)

data = {
  'userid': '',
  'token': '',
  'reqid': '',
  'path': 'jupiter/GET/kr/word',
  'eventId': '',
  'params': '{"logid":,"entry":"kr_station","attrWordContainTag":[],"needAutounit":false,"querytype":1,"query":"\u622A\u6B62\u9600","querySessions":["\u622A\u6B62\u9600"],"forceReload":true,"regions":"","device":0,"showWordContain":"","showWordNotContain":"","attrShowReasonTag":[],"attrBusinessPointTag":[],"filterAccountWord":true,"rgfilter":1,"planid":0,"unitid":0,"pageNo":1,"pageSize":300,"order":"","orderBy":""}'
}

response = requests.post('http://fengchao.baidu.com/nirvana/request.ajax', headers=headers, params=params, cookies=cookies, data=data)
```

2018-11-13，有人说，既然我能上百度，我为什么还要登陆账号，抓包复制数据给python脚本。
……emmmmm这是因为，我不知道cookie以及userid、token、reqid的获取来源。
所以目前就用这种笨办法。不过至少也比手动好了不少。

另外提供几个小点子：主关键词——比如python，放到百度里搜索一下，底部的相关搜索，也是一个很好的关键词来源，可以考虑百度竞价采集一遍关键词以后，再写一个代码，采集这些关键词的相关搜索关键词。

另外百度百科右侧部分的词条标题，也是和当前搜索关键词相关，这部分标题也可以采集过来，做专题。