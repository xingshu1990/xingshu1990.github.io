---
layout: 树莓派安装hexo 将树莓派当成移动博客编辑器
tags:
- 树莓派
- hexo
categories: 
- 其他
urlname: raspberry_hexo
date: 2020-06-24 14:06:48
---

### 需求分析
onenote——python代码高亮不好，缩进也有问题。所以优先不考虑。
为知笔记——几年前免费用的时候，好用到原地爆炸。
只不过现在商业化了，在有印象笔记等笔记类软件还在免费的状态下，就不考虑为知笔记了。
说实话，用hexo做笔记，其实有点装b的味道在里面，
不过，如果让我买一个域名，还要做备案，再买一个虚拟主机，或者去国外平台买一个服务器使用。
比较大可能会是，博客或者那啥上网，全部搭建好了，然后突然就，整个人进入贤者模式（就是半年没写一篇文章）。

于是优先考虑：免费、不用费心思折腾域名，于是在问了一遍微信群，优先选择了今天这篇文章说的【在树莓派上搭建Hexo 写博文】

2020/07/11 默认各位已经在github上搭建好代码仓库，以前在本地搭建好hexo，生成源码，上传到github上，能利用github的二级域名，
渲染源码，在浏览器中展示。

### 分析
#### 域名
Github的二级域名*.github.io，不难听。且百度站长工具也可以验证二级域名，
不过要做SEO的话不推荐二级域名，买一个域名绑定一下，可能还要修改一下模板。

#### 模板
hexo的模板有很多，不考虑SEO，以及美化的情况下，我选择next。

#### 搭建难度
github仓库搭建 ★★★（姿势不正确★★★★★）
node.js ★★★（树莓派下要设定path路径 不清楚这个东西的话）
java8 ★★★（树莓派下要设定path路径 不清楚这个东西的话）
hexo 只要上面这些搭建好了，这部分就不用怎么折腾，还是按照互联网上windows linux的安装配置方法就可以搞定。

### 搭建

目录结构

安装Node.js
添加国内镜像源
安装Git
配置Github账号
安装Hexo
连接Github与本地
写文章、发布文章
绑定域名
备份博客源文件
博客源代码下载
个性化设置（matery主题）
常见问题及解答（FAQ）
个性化设置（beantech主题，已停更）

#### 安装Node.js


#### 安装Git

在树莓派终端输入：
```
sudo apt-get install git
```
#### 配置Github账号
在树莓派终端输入下列命令修改全局用户名（注意将引号内替换为个人帐号）：
```
git config --global user.name "你的GitHub/Gitee用户名"
```

```
git config --global user.email "你的GitHub/Gitee邮箱"
```
然后查看是否已经配置好：
```
git config --list
```
不出意外的话，输入上面这条命令，会出现
user.name=你设置的用户名
user.email=你设置的邮箱


getconf LONG_BIT        # 查看系统位数
uname -a            # kernel 版本
/opt/vc/bin/vcgencmd  version   # firmware版本
strings /boot/start.elf  |  grep VC_BUILD_ID    # firmware版本
cat /proc/version       # kernel
cat /etc/os-release     # OS版本资讯
cat /etc/issue          # Linux distro 版本
cat /etc/debian_version     # Debian版本编号
在树莓派中，输入uname -a 查看kernel 版本
![我的树莓派查看kernel信息](https://i.loli.net/2020/07/11/uax2Pz9OjfNtp3m.jpg)