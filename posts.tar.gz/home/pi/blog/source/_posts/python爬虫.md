---
title: hexo博客搭建、优化备忘录
date: 2020-02-29 23:36:22

categories: 
- hexo
tags:
- URL设置
- 博客优化
urlname: hexo_build
description: 如果做过SEO优化工作，那么必然知道中文URL对搜索引擎不友好。于是需要将HEXO的URL英文化。
---
## 文章URL优化

### 需求分析

如果做过SEO优化工作，那么必然知道中文URL对搜索引擎不友好。
通常将文章URL规划为这样：

```
{域名}/{类目或者分类}/文章.html
```
于是我们需要这样操作：

### 将类目或者分类英文化

找到并编辑_config.yml中的# Category & Tag


![category_map_tag_map.jpg](https://i.loli.net/2020/03/03/NzMnhUSIGkqbxRl.jpg)
```
# Category & Tag
default_category: uncategorized
#今后有新的分类和关键词都需要在这里一一规划好
category_map:
  爬虫: spider
tag_map:
  爬虫: spider
```

### 设置文章URL

打开程序配置下的_config.yml，查找permalink，
原始内容如下：
```
permalink: :year/:month/:day/:title/
```
将其修改成这样：
```
permalink: :category/:urlname.html
```
urlname是在每篇博客的Front-matter中定义的一个变量。也是为每篇博客取的英文名字。

打开相应的文章的md文件，比如本篇文章

本文的配置如下：
```
---
title: hexo博客搭建、优化备忘录
date: 2020-02-29 23:36:22
#将文章放置在什么分类下面
categories: 
- 爬虫
tags:
- 爬虫
- Python
urlname: hexo_build
---

这部分可编写纯文本内容 Markdown
```