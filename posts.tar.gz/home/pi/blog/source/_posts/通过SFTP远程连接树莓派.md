---
title: Sublime Text3通过SFTP远程连接树莓派
date: 2020-06-20 16:34:42
tags:
- 树莓派 
- Sublime Text3
- SFTP
- 远程连接
categories: 
- 其他
urlname: raspberry_SFTP
---

### 需求重现
电脑系统是XP，或者有部分人的系统安装的是阉割版的系统，不能安装一些系统，
或者一些主板稀奇古怪的原因，导致不能安装W7及以上的系统，另外部分Python库只有linux下能安装运行。

于是就有了——安装Sublime Text3，通过SFTP远程连接树莓派，进行远程编辑代码的想法。

问题1：通过Xshell连接树莓派固定IP，使用nano、vim编辑py文件，他不想么？
答：对于我来说，确实不香。主要原因是nano的复制粘贴不方便，也没有代码补全，vim需要一定的学习成本，还不如直接一点，用安装好插件的sublime text3，编辑py代码，更改sftp的sftp-config.json文件，自动保存上传，然后再切换到xshell 进行远程调试。

问题2：为什么不用vscode、pychram远程连接？
答:vscode确实很好用，但是XP安装不起来（没办法，非程序员，只是传统行业中的销售人员，偶尔摸鱼看点Python编程）。pycharm对于系统配置要求比较高，安装旧版本的pycharm，也是比较卡，于是就优先考虑pycharm。

### 实行问题
我买的树莓派是3B+，通过下载https://packagecontrol.io/installation#st3 中的Package Control文件，安装或解压后使用，这个网络上文章比较多，今天就暂时不写了，以后可能补充。

安装好，并通过Package Control安装了SFTP以后，在本地新建一个文件夹，用来保存和上传文件使用。
通过sublime text3打开文件夹，sublime text3默认有一个侧边栏，点开上面新建的文件夹，右键点击sftp/ftp 会有一个Map to Remote ，sftp会默认在当前目录下新建：sftp-config.json这个文件。

    "type": "sftp",  //SSH连接选sftp
    //下面这些配置参考网络上的文章

    "save_before_upload": true,
    "upload_on_save": true,
    "sync_down_on_open": false,
    "sync_skip_deletes": false,
    "sync_same_age": true,
    "confirm_downloads": false,
    "confirm_sync": true,
    "confirm_overwrite_newer": false,
    
    "host": "192.168.1.*",  //树莓派wifi IP或者有线IP
    "user": "pi",           //默认账户是pi
    "password": "*",        //密码  
    "port": "22",           //端口不改
    
    "remote_path": "/home/pi",   //这个是重点，使用的是xshell连接到树莓派以后 树莓派提供的目录。
    //我原先设定这个目录为/opt/自建子目录/ 结果死也连接不上。


    未完待续……