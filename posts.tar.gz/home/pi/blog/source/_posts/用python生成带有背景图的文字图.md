---
title: 用python生成带有背景图的文字图
categories: 
- python
tags: 
- Python
urlname: py_image
description: 环境模拟，如果老板给一个excel的关键词，让你做出带有文字的文字图，文字居中。没找到python能自动这样处理的代码。
---

>环境模拟，如果老板给一个excel的关键词，让你做出带有文字的文字图，文字居中。没找到python能自动这样处理的代码。
#####需要解决的问题
* 来源关键词，数量比较大，网络上python生成图片的教程，都是单个关键词，生成单张图片的？
* 图片如何保存 - 中文.jpg？
* 文字能不能做到居中 ？


>一个python的大佬帮一个他的朋友折腾的东西，我这个只是大概模拟一下。
他要做的是，从数据库的某一个字段中，取出数据，然后用python生成带有背景图的，白底黑字图片。文字竖着，从右到左，文字居中。
我的这个伪代码，是生成带有背景图的文字图。

>同级目录下，存一张背景图，图片名字为1.jpg
另外还得去下载OpenCV的.whl文件，进行手动安装。
代码中有部分相同的代码，这个可以写成函数。
draw.text这一行，我这边因为考虑的是汉字所占的个数比例，直接算术计算，
实际还有字体大小，以及占位偏差，代码中没有上下居中，左右居中的方法。
```
# -*- coding: utf-8 -*-

"""
同级目录下，存一张背景图，图片名字为1.jpg
这个得去下载OpenCV的.whl文件，进行手动安装。
代码中有部分相同的代码，这个可以写成函数。

draw.text这一行，我这边因为考虑的是汉字所占的个数比例，直接算术计算，
实际还有字体大小，以及占位偏差，代码中没有上下居中，左右居中的方法。

"""
from PIL import Image, ImageDraw, ImageFont
import cv2
import numpy as np

#考虑到会有很多关键词，所以多关键词，放列表里，如['甘孜','内蒙古']
i = ["重生杀手的主角爱人"]

k = 0
for key in i: 
    if len(key)>5 and len(key)<11:
        img = cv2.imdecode(np.fromfile('1.jpg',dtype=np.uint8),-1) # 图片名称不能有汉字
        cv2img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB) # cv2和PIL中颜色的hex码的储存顺序不同
        pilimg = Image.fromarray(cv2img)

        # PIL图片上打印汉字
        draw = ImageDraw.Draw(pilimg) # 图片上打印
        font = ImageFont.truetype("simhei.ttf", 60, encoding="utf-8") # 参数1：字体文件路径，参数2：字体大小

        draw.text((int(img.shape[0]/5),int(img.shape[1]/3)), key, (255, 255, 255), font=font) # 参数1：打印坐标，参数2：文本，参数3：字体颜色，参数4：字体
        cv2charimg = cv2.cvtColor(np.array(pilimg), cv2.COLOR_RGB2BGR)
        # cv2.imshow("图片", cv2charimg) # 汉字窗口标题显示乱码
        cv2.imshow("photo"+str(k), cv2charimg)
        cv2.imencode('.jpg',cv2charimg)[1].tofile(key+".jpg")
        cv2.waitKey (0)
        cv2.destroyAllWindows()
        k+=1

    elif len(key)<5 and len(key)>3:
        img = cv2.imdecode(np.fromfile('1.jpg',dtype=np.uint8),cv2.IMREAD_UNCHANGED) # 名称不能有汉字

        cv2img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB) # cv2和PIL中颜色的hex码的储存顺序不同
        pilimg = Image.fromarray(cv2img)

        # PIL图片上打印汉字
        draw = ImageDraw.Draw(pilimg) # 图片上打印
        font = ImageFont.truetype("simhei.ttf", 30, encoding="utf-8") # 参数1：字体文件路径，参数2：字体大小
        draw.text((int(img.shape[0]/2+40),int(img.shape[1]/3)), key, (255, 255, 255), font=font)
        cv2charimg = cv2.cvtColor(np.array(pilimg), cv2.COLOR_RGB2BGR)
        # cv2.imshow("图片", cv2charimg) # 汉字窗口标题显示乱码
        cv2.imshow("photo"+str(k), cv2charimg)
        cv2.imencode('.jpg',cv2charimg)[1].tofile(key+".jpg")
        cv2.waitKey (0)
        cv2.destroyAllWindows()
        k+=1
    elif len(key)<=3:
        img = cv2.imdecode(np.fromfile('1.jpg',dtype=np.uint8),cv2.IMREAD_UNCHANGED) # 名称不能有汉字

        cv2img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB) # cv2和PIL中颜色的hex码的储存顺序不同
        pilimg = Image.fromarray(cv2img)

        # PIL图片上打印汉字
        draw = ImageDraw.Draw(pilimg) # 图片上打印
        font = ImageFont.truetype("simhei.ttf", 40, encoding="utf-8") # 参数1：字体文件路径，参数2：字体大小
        draw.text((int(img.shape[0]/1.8+36),int(img.shape[1]/3)), key, (255, 255, 255), font=font)
        cv2charimg = cv2.cvtColor(np.array(pilimg), cv2.COLOR_RGB2BGR)
        # cv2.imshow("图片", cv2charimg) # 汉字窗口标题显示乱码
        cv2.imshow("photo"+str(k), cv2charimg)
        cv2.imencode('.jpg',cv2charimg)[1].tofile(key+".jpg")
        cv2.waitKey (0)
        cv2.destroyAllWindows()
        k+=1

		
		
		
		
		
		
```